package com.libindev.resturants

import android.util.Log

open class Methods {

   open fun getString() {

        Log.d("ddd","dddd")
    }
    companion object {
       var name:String="libin"
    }
}