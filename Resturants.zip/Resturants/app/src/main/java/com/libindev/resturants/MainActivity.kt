package com.libindev.resturants

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.google.firebase.firestore.QuerySnapshot
import com.libindev.resturants.adapters.CustomAdapter


class MainActivity : AppCompatActivity() {

    // lateinit var query:Query

    companion object {
        val TAG:String="MAIN"

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Data.name="Libin"
         Log.d("fff",  Methods.name)//companion  variable.

        //getting recyclerview from xml
        val recyclerView = findViewById(R.id.recycler) as RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayout.HORIZONTAL, false)

        val model = ViewModelProviders.of(this).get(MainActivitityViewModel::class.java)
        model.getResturantMenuDocmt(this).observe(this, Observer<QuerySnapshot>{ resturantMenuDocmt ->
            if (resturantMenuDocmt != null) {
              //  for ( document in resturantMenuDocmt) {
        //
                  //Log.d(document.id, document.get("name") as String?)
        //        }}

                    // update UI
                    val adapter = CustomAdapter(resturantMenuDocmt)

                    //now adding the adapter to recyclerview
                    recyclerView.adapter = adapter

              //  }
            }
        })


    }
}
