package com.libindev.resturants

object Data : Methods() {

    lateinit var name :String

    @Override
    override fun getString() {
        super.getString()
    }

}