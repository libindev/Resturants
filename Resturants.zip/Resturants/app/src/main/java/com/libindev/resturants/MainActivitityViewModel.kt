package com.libindev.resturants

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QueryDocumentSnapshot
import com.google.firebase.firestore.QuerySnapshot

class MainActivitityViewModel : ViewModel() {
    private var resturantMenuDocmt: MutableLiveData<QuerySnapshot>? = null
    fun getResturantMenuDocmt(context: Context): LiveData<QuerySnapshot> {
        if (resturantMenuDocmt == null) {
            resturantMenuDocmt = MutableLiveData()
            loadUsers(context)
        }
        return resturantMenuDocmt as MutableLiveData<QuerySnapshot>
    }

    private fun loadUsers(context: Context) {
        FirebaseApp.initializeApp(context);
        val db = FirebaseFirestore.getInstance()

        db.collection("Resturant Menu")
            .orderBy("name", Query.Direction.ASCENDING)
            .get()
            .addOnSuccessListener { documents ->
               resturantMenuDocmt?.postValue(documents)
            }
            .addOnFailureListener { exception ->
                Log.w(MainActivity.TAG, "Error getting documents: ", exception)
            }
        // Do an asynchronous operation to fetch resturantMenuDocmt.
    }
}